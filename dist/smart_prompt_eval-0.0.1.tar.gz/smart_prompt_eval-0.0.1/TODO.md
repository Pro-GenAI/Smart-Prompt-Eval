

Evaluate gpt-5-nano.

Readme:
	Generate a logo.
	Add same badges as iRAT.
	Add my contact info like iRAT.
	Write a title & a subtitle in smaller font

Ask copilot to review - create an Issue.
	Review the code of my python package.

Test on python 3.10


Create an images to share on readme & social media.

Make repo public in Pro-GenAI org.
	Star the repo.

Share on LinkedIn & X - both eval method and results.
	- Mention that this is old problem found years ago but not solved.
	- Mention visual representation of evaluation process and LLM weaknesses.
	Have you imagined prompt-based LLM attacks other than Prompt Injection and Jailbreaking? We can use power of roles.
	Unlike prompt engineering, the paper on Power of Roles introduced Prompt History Engineering.

Tag major media, influencers, and researchers in the field, and Turing.
Send the project to Turing's research team to implement in the industry.

Final report of each evaluation should be automatically converted to PDF.
