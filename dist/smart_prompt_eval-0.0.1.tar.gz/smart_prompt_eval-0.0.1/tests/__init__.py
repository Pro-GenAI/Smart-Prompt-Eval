"""Tests for smart_prompt_eval package."""
