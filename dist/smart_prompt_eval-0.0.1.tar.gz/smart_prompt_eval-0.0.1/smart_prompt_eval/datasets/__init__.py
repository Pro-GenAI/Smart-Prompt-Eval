"""datasets subpackage for

This file makes the `datasets` directory importable as
`datasets` when the repository root is on PYTHONPATH.
"""

__all__ = []
