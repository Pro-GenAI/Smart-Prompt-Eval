"""Smart Prompt Evaluation Tools."""

__version__ = "0.0.1"
