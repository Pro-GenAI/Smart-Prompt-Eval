"""Utility functions for smart prompt evaluation."""
